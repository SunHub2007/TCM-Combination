"""Score saved MOEA runs against the reference set and, where it is complete, the exact front.

Example:
    python scripts/evaluate.py results/moea/F6/lam1/SparseEA/B20000
"""
import argparse
import csv
import pathlib
import sys

import numpy as np

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from tcmsel.indicators import hv3d, igd_plus, nondominated  # noqa: E402

REF = 1.0 + 1.0 / 12.0


def exact_front(name, lam):
    path = ROOT / 'data' / 'exact' / f'{name}_lam{lam:g}.csv'
    rows = list(csv.DictReader(open(path)))
    F = np.array([[float(r['f1']), float(r['f2']), float(r['f3'])] for r in rows])
    return F[nondominated(F)]


def is_complete(name, lam):
    for r in csv.DictReader(open(ROOT / 'data' / 'exact' / 'summary.csv')):
        if r['instance'] == name and float(r['lam']) == lam:
            return r['complete'] == 'True'
    return False


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('run_dir', help='directory .../<instance>/lam<lam>/<alg>/B<budget> with r*.npz files')
    a = p.parse_args()
    d = pathlib.Path(a.run_dir)
    name, lam = d.parents[2].name, float(d.parents[1].name[3:])
    ref = np.load(ROOT / 'data' / 'reference_sets' / f'{name}_lam{lam:g}.npz')
    lo, hi = ref['lo'], ref['hi']
    span = np.where(hi > lo, hi - lo, 1.0)
    norm = lambda F: (F - lo) / span  # noqa: E731
    r = np.full(3, REF)
    Rn = norm(ref['F'])
    hv_ref = hv3d(Rn, r)
    hv_exact = hv3d(norm(exact_front(name, lam)), r) if is_complete(name, lam) else np.nan
    print('run   relative HV   HV ratio      IGD+')
    for f in sorted(d.glob('r*.npz')):
        x = np.load(f)
        F = x['objs'][np.all(x['cons'] <= 0, axis=1)]
        hv = hv3d(norm(F), r) if len(F) else 0.0
        ratio = hv / hv_exact if np.isfinite(hv_exact) else np.nan
        print(f'{f.stem}  {hv / hv_ref:11.4f}  {ratio:9.4f}  {igd_plus(norm(F), Rn):8.4f}')


if __name__ == '__main__':
    main()
