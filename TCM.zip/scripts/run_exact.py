"""Compute the Pareto front of one instance with the augmented epsilon-constraint method.

The ten size limits k = 1, ..., 10 are solved in parallel processes. Requires PySCIPOpt.

Example:
    python scripts/run_exact.py --instance F6 --lam 0
"""
import argparse
import json
import pathlib
import sys
import time
from multiprocessing import Pool

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tcmsel import problem  # noqa: E402
from tcmsel.exact import solve_k  # noqa: E402


def job(args):
    name, lam, k, t_point, t_total = args
    t0 = time.time()
    recs = solve_k(problem.load(name), lam, k, t_point=t_point, t_total=t_total)
    return k, recs, time.time() - t0


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--instance', required=True)
    p.add_argument('--lam', type=float, required=True)
    p.add_argument('--time-per-model', type=float, default=3600.0, help='seconds')
    p.add_argument('--time-per-k', type=float, default=14400.0, help='seconds')
    p.add_argument('--out', default='results/exact')
    a = p.parse_args()
    ks = range(1, problem.K_MAX + 1)
    with Pool(len(ks)) as pool:
        res = pool.map(job, [(a.instance, a.lam, k, a.time_per_model, a.time_per_k) for k in ks])
    out = pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    path = out / f'{a.instance}_lam{a.lam:g}.json'
    json.dump({'instance': a.instance, 'lam': a.lam,
               'per_k': [{'k': k, 'time': t, 'records': r} for k, r, t in res]}, open(path, 'w'), indent=1)
    for k, r, t in res:
        print(f'k = {k:2d}: {sum("f1" in x for x in r):3d} points, {t:9.1f} s')
    print(path)


if __name__ == '__main__':
    main()
