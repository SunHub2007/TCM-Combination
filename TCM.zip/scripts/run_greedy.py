"""Evaluate the combinations of degree ranking and cumulative contribution on one instance.

Example:
    python scripts/run_greedy.py --instance F4 --lam 1
"""
import argparse
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tcmsel import greedy, problem  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--instance', required=True)
    p.add_argument('--lam', type=float, required=True)
    a = p.parse_args()
    inst = problem.load(a.instance)
    cc, frac = greedy.cumulative_contribution(inst)
    k90 = next((j + 1 for j, v in enumerate(frac) if v >= 0.9), None)
    for label, order in (('Degree ranking', greedy.degree_ranking(inst)), ('Cumulative contribution', cc)):
        F = inst.objectives(greedy.combinations(order, inst.N, problem.K_MAX), a.lam)
        print(label)
        print('   k        f1        f3')
        for k, f in enumerate(F, 1):
            print(f'  {k:2d}  {f[0]:8.4f}  {f[2]:8.4f}')
    print(f'Compounds needed by cumulative contribution for 90% coverage: {k90}')


if __name__ == '__main__':
    main()
