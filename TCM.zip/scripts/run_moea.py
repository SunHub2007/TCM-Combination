"""Run one MOEA on one instance and save the final population.

Example:
    python scripts/run_moea.py --instance F6 --lam 1 --alg SparseEA --budget 20000 --run 0
"""
import argparse
import pathlib
import sys

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from tcmsel import runner  # noqa: E402
from tcmsel.algorithms import ALGORITHMS  # noqa: E402


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('--instance', required=True, help='F1, F2, F3, F4, F6, F8, ALL, or ALL_n40_r0 ... ALL_n60_r9')
    p.add_argument('--lam', type=float, required=True, choices=runner.LAMBDAS)
    p.add_argument('--alg', required=True, choices=list(ALGORITHMS))
    p.add_argument('--budget', type=int, default=20000, choices=runner.BUDGETS)
    p.add_argument('--run', type=int, default=0, help='run index 0-29')
    p.add_argument('--no-greedy', action='store_true', help='start without greedy initial solutions')
    p.add_argument('--no-exposure', action='store_true', help='set all exposure weights e_i to 1')
    p.add_argument('--out', default='results/moea', help='output directory')
    a = p.parse_args()
    res = runner.run(a.instance, a.lam, a.alg, a.budget, a.run, greedy=not a.no_greedy, no_exposure=a.no_exposure)
    path = pathlib.Path(a.out) / a.instance / f'lam{a.lam:g}' / a.alg.replace('/', '-') / f'B{a.budget}' / f'r{a.run:02d}.npz'
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, **res)
    feasible = int(np.all(res['cons'] <= 0, axis=1).sum())
    print(f'{path}: {feasible} feasible solutions, {res["fe"]} evaluations, {res["wall"]:.1f} s')


if __name__ == '__main__':
    main()
