"""Budgeted problem evaluation and population container used by all algorithms."""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


class SOTask:

    def __init__(self, problem, max_fes: int, seed: int, n_ckpt: int = 50):
        self.problem = problem
        self.dim = int(problem.dim)
        self.lb = np.asarray(problem.lb, dtype=float) * np.ones(self.dim)
        self.ub = np.asarray(problem.ub, dtype=float) * np.ones(self.dim)
        self.max_fes = int(max_fes)
        self.seed = int(seed)
        self.rng = np.random.default_rng(seed)
        self.fes = 0
        self.best_f = np.inf
        self.best_x = None
        self.ckpt = [self.max_fes * k // n_ckpt for k in range(1, n_ckpt + 1)]
        self.curve: list[float] = []

    @property
    def remaining(self) -> int:
        return self.max_fes - self.fes

    @property
    def done(self) -> bool:
        return self.fes >= self.max_fes

    def evaluate(self, X) -> np.ndarray:
        X = np.atleast_2d(np.asarray(X, dtype=float))
        n = X.shape[0]
        out = np.full(n, np.inf)
        k = min(n, max(self.remaining, 0))
        if k == 0:
            return out
        f = np.asarray(self.problem.f(X[:k]), dtype=float).reshape(-1)
        out[:k] = f
        for i in range(k):
            self.fes += 1
            if f[i] < self.best_f:
                self.best_f = float(f[i])
                self.best_x = X[i].copy()
            while len(self.curve) < len(self.ckpt) and self.fes == self.ckpt[len(self.curve)]:
                self.curve.append(self.best_f)
        return out

    def evaluate1(self, x) -> float:
        return float(self.evaluate(np.asarray(x)[None, :])[0])

    def result(self, **extra) -> "SOResult":
        opt = getattr(self.problem, "optimum", None)
        return SOResult(best_f=self.best_f, best_x=self.best_x, fes=self.fes, curve=list(self.curve),
                        error=None if opt is None else self.best_f - opt, extra=extra)


@dataclass
class SOResult:
    best_f: float
    best_x: np.ndarray | None
    fes: int
    curve: list = field(default_factory=list)
    error: float | None = None
    extra: dict = field(default_factory=dict)


class Pop:

    __slots__ = ("decs", "objs", "cons", "adds")

    def __init__(self, decs, objs, cons, adds=None):
        self.decs = np.asarray(decs, dtype=float).reshape(len(decs), -1) if len(decs) else np.zeros((0, 0))
        self.objs = np.asarray(objs, dtype=float).reshape(len(decs), -1) if len(decs) else np.zeros((0, 0))
        self.cons = np.asarray(cons, dtype=float).reshape(len(decs), -1) if len(decs) else np.zeros((0, 0))
        self.adds = None if adds is None else np.asarray(adds, dtype=float).reshape(len(decs), -1)

    def __len__(self):
        return self.decs.shape[0]

    def __getitem__(self, idx):
        idx = _as_index(idx)
        return Pop(self.decs[idx], self.objs[idx], self.cons[idx],
                   None if self.adds is None else self.adds[idx])

    @staticmethod
    def cat(*pops: "Pop") -> "Pop":
        pops = [p for p in pops if p is not None and len(p) > 0]
        if not pops:
            return Pop.empty()
        adds = None
        if all(p.adds is not None for p in pops):
            adds = np.vstack([p.adds for p in pops])
        return Pop(np.vstack([p.decs for p in pops]), np.vstack([p.objs for p in pops]),
                   np.vstack([p.cons for p in pops]), adds)

    @staticmethod
    def empty() -> "Pop":
        p = Pop.__new__(Pop)
        p.decs = p.objs = p.cons = np.zeros((0, 0))
        p.adds = None
        return p

    @property
    def cv(self) -> np.ndarray:
        return np.sum(np.maximum(0.0, self.cons), axis=1)

    @property
    def feasible(self) -> np.ndarray:
        return np.all(self.cons <= 0, axis=1)

    def with_adds(self, adds) -> "Pop":
        return Pop(self.decs, self.objs, self.cons, adds)


def _as_index(idx):
    if isinstance(idx, (int, np.integer)):
        return np.array([idx])
    if isinstance(idx, list):
        return np.asarray(idx, dtype=int) if not (idx and isinstance(idx[0], (bool, np.bool_))) else np.asarray(idx)
    return idx


class MOTask:

    def __init__(self, problem, N: int, max_fes: int, seed: int, n_save: int = 1):
        self.problem = problem
        self.M, self.D = int(problem.M), int(problem.D)
        self.lower = np.asarray(problem.lower, dtype=float) * np.ones(self.D)
        self.upper = np.asarray(problem.upper, dtype=float) * np.ones(self.D)
        self.encoding = np.asarray(getattr(problem, "encoding", np.ones(self.D)), dtype=int) * np.ones(self.D, dtype=int)
        self.N = int(N)
        self.max_fes = int(max_fes)
        self.seed = int(seed)
        self.rng = np.random.default_rng(seed)
        self.FE = 0
        self.n_save = max(1, int(n_save))
        self.history: list[tuple[int, Pop]] = []
        self.final: Pop | None = None


    @property
    def maxFE(self) -> int:
        return self.max_fes

    def cal_dec(self, dec):
        if hasattr(self.problem, "cal_dec"):
            return self.problem.cal_dec(dec)
        dec = np.minimum(np.maximum(dec, self.lower), self.upper)
        idx = np.isin(self.encoding, (2, 3, 4))
        if idx.any():
            dec[:, idx] = np.round(dec[:, idx])
        return dec

    def evaluate(self, dec, add=None) -> Pop:
        dec = np.atleast_2d(np.array(dec, dtype=float, copy=True))
        dec = self.cal_dec(dec)
        obj = np.asarray(self.problem.cal_obj(dec), dtype=float).reshape(dec.shape[0], -1)
        con = np.asarray(self.problem.cal_con(dec), dtype=float).reshape(dec.shape[0], -1)
        self.FE += dec.shape[0]
        return Pop(dec, obj, con, add)

    def initialization(self, N: int | None = None) -> Pop:
        N = self.N if N is None else int(N)
        dec = np.zeros((N, self.D))
        enc = self.encoding
        r = (enc == 1) | (enc == 2) | (enc == 3)
        if r.any():
            u = self.rng.uniform(self.lower[r], self.upper[r], size=(N, int(r.sum())))
            dec[:, r] = u
            ir = np.isin(enc, (2, 3))
            if ir.any():
                dec[:, ir] = np.round(dec[:, ir])
        b = enc == 4
        if b.any():
            dec[:, b] = self.rng.integers(0, 2, size=(N, int(b.sum())))
        p = enc == 5
        if p.any():
            dec[:, p] = np.argsort(self.rng.random((N, int(p.sum()))), axis=1) + 1
        dec = self.insert_greedy(dec)
        return self.evaluate(dec)


    greedy_decs = None

    def insert_greedy(self, M):
        if self.greedy_decs is None or len(M) == 0:
            return M
        n = min(len(self.greedy_decs), len(M))
        M = M.copy()
        M[:n] = np.asarray(self.greedy_decs[:n]).astype(M.dtype)
        return M

    def not_terminated(self, pop: Pop) -> bool:
        self.final = pop
        if self.n_save > 1:
            k = max(1, min(self.n_save, int(np.ceil(self.n_save * self.FE / self.max_fes))))
            if not self.history or self.history[-1][0] < k:
                self.history.append((k, pop))
        return self.FE < self.max_fes

    def result(self, **extra) -> "MOResult":
        p = self.final if self.final is not None else Pop.empty()
        return MOResult(decs=p.decs, objs=p.objs, cons=p.cons, fes=self.FE, extra=extra)


@dataclass
class MOResult:
    decs: np.ndarray
    objs: np.ndarray
    cons: np.ndarray
    fes: int
    extra: dict = field(default_factory=dict)
