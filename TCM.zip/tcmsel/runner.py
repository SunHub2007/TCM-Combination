"""Single MOEA run with greedy initial solutions, as used in the experiments."""
from __future__ import annotations

import importlib
import time

import numpy as np

from tcmsel import problem
from tcmsel.algorithms import ALGORITHMS
from tcmsel.core import MOTask

INSTANCES = ['F1', 'F2', 'F3', 'F4', 'F6', 'F8', 'ALL']
LAMBDAS = [0.0, 0.5, 1.0]
BUDGETS = [2000, 5000, 10000, 20000]
POPULATION = 100


def instance_index(name):
    if name in INSTANCES:
        return INSTANCES.index(name)
    n, r = name.split('_n')[1].split('_r')
    return 10 + (0 if n == '40' else 10) + int(r)


def random_seed(name, lam, budget, run):
    """Seed of the random generator for one run (reproduces the reported runs)."""
    return 9_000_000 + 10_000 * instance_index(name) + 1_000 * LAMBDAS.index(lam) + 100 * BUDGETS.index(budget) + run


def greedy_solutions(task, budget):
    """Prefixes of a greedy sequence that adds the compound with the smallest f1; at most 10% of the budget."""
    cap = int(0.10 * budget)
    S = np.zeros(task.D)
    sols, used = [], 0
    for _ in range(problem.K_MAX):
        cand = np.flatnonzero(S == 0)
        if used + len(cand) > cap or len(cand) == 0:
            break
        X = np.tile(S, (len(cand), 1))
        X[np.arange(len(cand)), cand] = 1
        pop = task.evaluate(X)
        used += len(cand)
        best = cand[int(np.argmin(pop.objs[:, 0]))]
        S = S.copy()
        S[best] = 1
        sols.append(S.copy())
    return (np.array(sols) if sols else None), used


def run(name, lam, alg, budget, run_id, greedy=True, no_exposure=False, seed=None):
    """Run one algorithm once and return a dictionary with the final population and run statistics."""
    inst = problem.load(name, no_exposure=no_exposure)
    task = MOTask(problem.Problem(inst, lam), N=POPULATION, max_fes=budget,
                  seed=random_seed(name, lam, budget, run_id) if seed is None else seed)
    t0, c0 = time.time(), time.process_time()
    cost = 0
    if greedy and alg != 'Random':
        task.greedy_decs, cost = greedy_solutions(task, budget)
    module = importlib.import_module('tcmsel.algorithms.' + ALGORITHMS[alg])
    res = module.run(task, **module.DEFAULTS)
    return {'objs': res.objs, 'decs': res.decs.astype(np.int8), 'cons': res.cons, 'fe': res.fes,
            'wall': time.time() - t0, 'cpu': time.process_time() - c0, 'greedy_cost': cost, 'seed': task.seed}
