"""Exact and evolutionary multi-objective selection of minimal compound combinations."""

__version__ = '1.0.0'
