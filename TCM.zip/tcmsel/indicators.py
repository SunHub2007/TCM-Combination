"""Non-dominated filter, exact three-dimensional hypervolume, and IGD+ (minimization)."""
from __future__ import annotations

import numpy as np


def nondominated(F):
    F = np.asarray(F, dtype=float)
    if len(F) == 0:
        return np.zeros(0, bool)
    _, first = np.unique(F, axis=0, return_index=True)
    keep = np.zeros(len(F), bool); keep[first] = True
    idx = np.flatnonzero(keep)
    G = F[idx]
    dom = np.zeros(len(G), bool)
    for i in range(len(G)):
        if dom[i]:
            continue
        le = np.all(G <= G[i], axis=1) & np.any(G < G[i], axis=1)
        if le.any():
            dom[i] = True
    out = np.zeros(len(F), bool); out[idx[~dom]] = True
    return out


def hv2d(P, r):
    P = P[np.all(P < r, axis=1)]
    if len(P) == 0:
        return 0.0
    P = P[np.argsort(P[:, 0], kind='stable')]
    hv, best2 = 0.0, r[1]
    for k in range(len(P)):
        x1 = P[k + 1, 0] if k + 1 < len(P) else r[0]
        best2 = min(best2, P[k, 1])
        hv += (x1 - P[k, 0]) * (r[1] - best2)
    return hv


def hv3d(P, r):
    P = np.asarray(P, dtype=float)
    r = np.asarray(r, dtype=float)
    P = P[np.all(P < r, axis=1)]
    if len(P) == 0:
        return 0.0
    P = P[nondominated(P)]
    P = P[np.argsort(P[:, 2], kind='stable')]
    hv = 0.0
    for k in range(len(P)):
        z0 = P[k, 2]
        z1 = P[k + 1, 2] if k + 1 < len(P) else r[2]
        if z1 > z0:
            hv += hv2d(P[:k + 1, :2], r[:2]) * (z1 - z0)
    return hv


def igd_plus(A, Z):
    A = np.asarray(A, dtype=float); Z = np.asarray(Z, dtype=float)
    if len(A) == 0:
        return np.inf
    d = np.maximum(A[None, :, :] - Z[:, None, :], 0.0)
    return float(np.sqrt((d ** 2).sum(axis=2)).min(axis=1).mean())
