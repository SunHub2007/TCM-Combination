"""Greedy selection rules of network pharmacology: degree ranking and cumulative contribution."""
from __future__ import annotations

import numpy as np


def degree_ranking(inst):
    """Compounds in decreasing order of their number of COPD targets; ties broken by exposure weight."""
    deg = inst.B.sum(axis=1)
    return sorted(range(inst.N), key=lambda i: (-deg[i], -inst.e[i], i))


def cumulative_contribution(inst):
    """Add at each step the compound that covers the most targets not yet covered.

    Returns the order of the chosen compounds and the covered fraction of the targets after each step."""
    deg = inst.B.sum(axis=1)
    covered = np.zeros(inst.T, bool)
    chosen, frac = [], []
    left = set(range(inst.N))
    while left and not covered.all():
        gain = {i: int((inst.B[i] > 0)[~covered].sum()) for i in left}
        best = max(left, key=lambda i: (gain[i], deg[i], inst.e[i], -i))
        if gain[best] == 0:
            break
        chosen.append(best)
        left.discard(best)
        covered |= inst.B[best] > 0
        frac.append(covered.mean())
    return chosen, frac


def combinations(order, n, k_max):
    """Binary matrix of the k_max nested combinations formed by the first k compounds of an order."""
    X = np.zeros((k_max, n))
    for k in range(1, k_max + 1):
        X[k - 1, order[:k]] = 1
    return X
