"""Three-objective selection of a minimal compound combination.

For x in {0,1}^N and S = {i : x_i = 1}, all objectives are minimized:
    f1 = -( sum_t w_t a_t(S) / sum_t w_t + lam * sum_{i<j in S} c_ij / Z_c ),  a_t = 1 - exp(-sum_{i in S} e_i b_it)
    f2 = |S|
    f3 = max_{i in S} tau_i + lam * sum_{i<j in S} delta_ij / Z_delta
subject to 1 <= |S| <= K_MAX.
"""
from __future__ import annotations

import pathlib

import numpy as np

K_MAX = 10
DATA = pathlib.Path(__file__).resolve().parent.parent / 'data' / 'instances'


class Instance:
    """Arrays of one candidate pool: known pairs B (N x T), target weights w, exposure weights e, toxicity tox,
    complementarity CE (N x N), and CYP co-inhibition DDI (N x N)."""

    def __init__(self, path, no_exposure=False):
        d = np.load(path, allow_pickle=False)
        self.name = pathlib.Path(path).stem
        self.ik14 = d['ik14']
        self.B = d['B'].astype(float)
        self.w = d['w'].astype(float)
        self.e = np.ones(len(d['e'])) if no_exposure else d['e'].astype(float)
        self.tox = d['tox'].astype(float)
        self.CE = d['CE'].astype(float)
        self.DDI = d['DDI'].astype(float)
        self.Z_ce = float(d['Z_ce'])
        self.Z_ddi = float(d['Z_ddi'])
        self.N, self.T = self.B.shape
        self.EB = self.e[:, None] * self.B
        self.W = float(self.w.sum())
        self.CEu = np.triu(self.CE, 1)
        self.DDIu = np.triu(self.DDI, 1)

    def objectives(self, X, lam):
        X = np.asarray(X, dtype=float)
        Y = X @ self.EB
        cov = (1.0 - np.exp(-Y)) @ self.w / self.W
        ce = np.einsum('ij,ij->i', X @ self.CEu, X) / self.Z_ce
        ddi = np.einsum('ij,ij->i', X @ self.DDIu, X) / self.Z_ddi
        mtox = np.max(np.where(X > 0.5, self.tox[None, :], 0.0), axis=1)
        return np.column_stack([-(cov + lam * ce), X.sum(axis=1), mtox + lam * ddi])


class Problem:
    """Binary problem with three objectives and two constraints (<= 0 is feasible)."""

    def __init__(self, inst: Instance, lam: float):
        self.inst, self.lam = inst, float(lam)
        self.M, self.D = 3, inst.N
        self.lower, self.upper = np.zeros(inst.N), np.ones(inst.N)
        self.encoding = 4 * np.ones(inst.N, dtype=int)
        self.name = f'{inst.name}_lam{lam:g}'

    def cal_dec(self, dec):
        return (np.asarray(dec) > 0.5).astype(float)

    def cal_obj(self, dec):
        return self.inst.objectives(dec, self.lam)

    def cal_con(self, dec):
        k = np.asarray(dec).sum(axis=1)
        return np.column_stack([1.0 - k, k - K_MAX])


def load(name, no_exposure=False):
    """Load an instance by name, e.g. 'F6', 'ALL', or 'ALL_n40_r1'."""
    return Instance(DATA / f'{name}.npz', no_exposure=no_exposure)
