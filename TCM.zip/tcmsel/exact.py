"""Augmented epsilon-constraint method (AUGMECON2 style) with SCIP.

For a size limit k, a sequence of models maximizes the efficacy -f1 plus eta * (u2 / r2 + u3 / r3)
subject to f2 + u2 = k, f3 + u3 = eps, u2, u3 >= 0, and f2 >= 1. After each solution, eps is set to
f3 - STEP; the sequence ends when the model is infeasible or eps falls below the smallest toxicity.
"""
from __future__ import annotations

import time

import numpy as np
from pyscipopt import Model, exp, quicksum

from tcmsel.problem import K_MAX

STEP = 0.001
ETA = 1e-3


def _model(inst, lam, k, eps3, tlim, gap, r3):
    m = Model()
    m.hideOutput()
    m.setParam('limits/time', max(1.0, float(tlim)))
    m.setParam('limits/gap', gap)
    m.setParam('parallel/maxnthreads', 1)
    x = [m.addVar(vtype='B', name=f'x{i}') for i in range(inst.N)]
    a = [m.addVar(lb=0.0, ub=1.0, name=f'a{t}') for t in range(inst.T)]
    for t in range(inst.T):
        nz = np.flatnonzero(inst.EB[:, t] > 0)
        m.addCons(a[t] + exp(-quicksum(float(inst.EB[i, t]) * x[i] for i in nz)) <= 1.0)
    efficacy = quicksum(float(inst.w[t]) * a[t] for t in range(inst.T)) / inst.W
    if lam > 0:
        pairs = np.argwhere(inst.CEu > 0)
        if len(pairs):
            c = m.addVar(lb=0.0, ub=float(len(pairs)), name='ce')
            m.addCons(c <= quicksum(x[i] * x[j] for i, j in pairs))
            efficacy = efficacy + lam * c / inst.Z_ce
    mt = m.addVar(lb=0.0, ub=1.0, name='mtox')
    for i in range(inst.N):
        m.addCons(mt >= float(inst.tox[i]) * x[i])
    f3 = mt
    if lam > 0:
        dp = np.argwhere(inst.DDIu > 0)
        f3 = mt + lam * quicksum(float(inst.DDIu[i, j]) * x[i] * x[j] for i, j in dp) / inst.Z_ddi
    u2 = m.addVar(lb=0.0, name='u2')
    u3 = m.addVar(lb=0.0, name='u3')
    m.addCons(quicksum(x) + u2 == k)
    m.addCons(quicksum(x) >= 1)
    m.addCons(f3 + u3 == eps3)
    obj = m.addVar(lb=-1e6, ub=1e6, name='obj')
    m.addCons(obj <= efficacy + ETA * (u2 / max(K_MAX - 1, 1) + u3 / r3))
    m.setObjective(obj, 'maximize')
    return m, x


def solve_k(inst, lam, k, t_point=3600.0, t_total=14400.0, gap=1e-4):
    """Return the points found for size limit k as a list of dictionaries."""
    f3_hi = float(inst.tox.max()) + lam + STEP
    r3 = max(f3_hi - float(inst.tox.min()), 1e-6)
    eps3, out, t0 = f3_hi, [], time.time()
    while eps3 >= float(inst.tox.min()) - 1e-12:
        left = t_total - (time.time() - t0)
        if left <= 0:
            out.append({'k': k, 'eps3': eps3, 'status': 'time_limit_per_k'})
            break
        m, x = _model(inst, lam, k, eps3, min(t_point, left), gap, r3)
        ts = time.time()
        m.optimize()
        dt = time.time() - ts
        status = m.getStatus()
        if m.getNSols() == 0:
            out.append({'k': k, 'eps3': eps3, 'status': status, 'time': dt})
            break
        xs = np.array([round(m.getVal(v)) for v in x], dtype=float)
        f = inst.objectives(xs[None, :], lam)[0]
        out.append({'k': k, 'eps3': eps3, 'status': status, 'gap': float(m.getGap()), 'time': dt,
                    'f1': float(f[0]), 'f2': float(f[1]), 'f3': float(f[2]), 'x': np.flatnonzero(xs).tolist()})
        eps3 = f[2] - STEP
    return out
