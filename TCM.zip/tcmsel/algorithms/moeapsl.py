"""MOEA/PSL (Tian et al., 2021) for large-scale sparse problems, binary encoding."""
from __future__ import annotations

import math

import numpy as np

from tcmsel.core import Pop
from tcmsel.operators import CrowdingDistance, NDSort, TournamentSelection, UniformPoint, msort, unique_rows

NAME = "MOEA/PSL"
YEAR = 2021
REFERENCE = ("Y. Tian, C. Lu, X. Zhang, K. C. Tan, and Y. Jin. Solving large-scale multi-objective optimization "
             "problems with sparse optimal solutions via unsupervised neural networks. IEEE Transactions on "
             "Cybernetics, 2021, 51(6): 3115-3128.")
CODING = "real/integer/binary"
DEFAULTS: dict = {}


def _sigmoid(x):
    with np.errstate(over="ignore", invalid="ignore"):
        return 1.0 / (1.0 + np.exp(-x))


def _msum(A):
    A = np.asarray(A, dtype=float)
    if A.shape[0] == 1:
        return A.sum()
    return A.sum(axis=0)


class RBM:
    def __init__(self, nVisible, nHidden, Epoch, BatchSize, Penalty, Momentum, LearnRate, rng):
        self.nVisible, self.nHidden = int(nVisible), int(nHidden)
        self.Epoch, self.BatchSize = int(Epoch), int(BatchSize)
        self.Penalty, self.Momentum, self.LearnRate = Penalty, Momentum, LearnRate
        self.rng = rng
        self.Weight = 0.1 * rng.standard_normal((self.nVisible, self.nHidden))
        self.vBias = np.zeros((1, self.nVisible))
        self.hBias = np.zeros((1, self.nHidden))

    def train(self, X):
        rng = self.rng
        X = np.asarray(X, dtype=float)
        vishidinc = np.zeros(self.Weight.shape)
        hidbiasinc = np.zeros(self.hBias.shape)
        visbiasinc = np.zeros(self.vBias.shape)
        B = self.BatchSize
        for epoch in range(self.Epoch):
            if self.Epoch > 5:
                self.Momentum = 0.9
            kk = rng.permutation(X.shape[0])
            for batch in range(int(X.shape[0] / B)):
                batchdata = X[kk[batch * B:(batch + 1) * B]]

                poshidprobs = _sigmoid(batchdata @ self.Weight + np.tile(self.hBias, (B, 1)))
                poshidstates = (poshidprobs > rng.random((B, self.nHidden))).astype(float)

                negdataprobs = _sigmoid(poshidstates @ self.Weight.T + np.tile(self.vBias, (B, 1)))
                negdata = (negdataprobs > rng.random((B, self.nVisible))).astype(float)
                neghidprobs = _sigmoid(negdata @ self.Weight + np.tile(self.hBias, (B, 1)))

                posprods = batchdata.T @ poshidprobs
                negprods = negdataprobs.T @ neghidprobs
                poshidact = _msum(poshidprobs)
                posvisact = _msum(batchdata)
                neghidact = _msum(neghidprobs)
                negvisact = _msum(negdata)
                vishidinc = self.Momentum * vishidinc + self.LearnRate * (
                    ((posprods - negprods) / B) - self.Penalty * self.Weight)
                visbiasinc = self.Momentum * visbiasinc + (self.LearnRate / B) * (posvisact - negvisact)
                hidbiasinc = self.Momentum * hidbiasinc + (self.LearnRate / B) * (poshidact - neghidact)
                self.Weight = self.Weight + vishidinc
                self.vBias = self.vBias + visbiasinc
                self.hBias = self.hBias + hidbiasinc

    def reduce(self, X):
        X = np.asarray(X, dtype=float)
        return _sigmoid(X @ self.Weight + np.tile(self.hBias, (X.shape[0], 1))) > \
            self.rng.random((X.shape[0], self.Weight.shape[1]))

    def recover(self, H):
        H = np.asarray(H, dtype=float)
        return _sigmoid(H @ self.Weight.T + np.tile(self.vBias, (H.shape[0], 1))) > \
            self.rng.random((H.shape[0], self.Weight.shape[0]))


class DAE:
    def __init__(self, nVisible, nHidden, Epoch, BatchSize, InputZeroMaskedFraction, Momentum, LearnRate, rng):
        self.nVisible, self.nHidden = int(nVisible), int(nHidden)
        self.Epoch, self.BatchSize = int(Epoch), int(BatchSize)
        self.InputZeroMaskedFraction = InputZeroMaskedFraction
        self.Momentum, self.LearnRate = Momentum, LearnRate
        self.rng = rng
        self.WA = (rng.random((self.nHidden, self.nVisible + 1)) - 0.5) * 8 * math.sqrt(6 / (self.nHidden + self.nVisible))
        self.WB = (rng.random((self.nVisible, self.nHidden + 1)) - 0.5) * 8 * math.sqrt(6 / (self.nVisible + self.nHidden))
        self.lower = None
        self.upper = None

    def _norm(self, X):
        with np.errstate(divide="ignore", invalid="ignore"):
            return (X - self.lower[None, :]) / (self.upper - self.lower)[None, :]

    def train(self, X):
        rng = self.rng
        X = np.asarray(X, dtype=float)
        self.lower = np.fmin.reduce(X, axis=0)
        self.upper = np.fmax.reduce(X, axis=0)
        X = self._norm(X)
        n = X.shape[0]
        vW = [np.zeros(self.WA.shape), np.zeros(self.WB.shape)]
        if self.InputZeroMaskedFraction != 0:
            theta = rng.random(X.shape) > self.InputZeroMaskedFraction
        else:
            theta = np.ones(X.shape, dtype=bool)
        X_temp = X * theta
        X_temp = np.hstack([np.ones((n, 1)), X_temp])
        B = self.BatchSize
        with np.errstate(over="ignore", invalid="ignore"):
            for _ in range(self.Epoch):
                kk = rng.permutation(n)
                for batch in range(int(n / B)):
                    sel = kk[batch * B:(batch + 1) * B]
                    batch_x = X_temp[sel]
                    batch_y = X[sel]

                    poshid1 = _sigmoid(batch_x @ self.WA.T)
                    poshid1 = np.hstack([np.ones((B, 1)), poshid1])
                    poshid2 = _sigmoid(poshid1 @ self.WB.T)

                    e = batch_y - poshid2
                    d3 = -e * (poshid2 * (1 - poshid2))
                    d_act = poshid1 * (1 - poshid1)
                    d2 = (d3 @ self.WB) * d_act
                    dW = [(d2[:, 1:].T @ batch_x) / d2.shape[0],
                          (d3.T @ poshid1) / d3.shape[0]]
                    for i in range(2):
                        dW[i] = self.LearnRate * dW[i]
                        if self.Momentum > 0:
                            vW[i] = self.Momentum * vW[i] + dW[i]
                            dW[i] = vW[i]
                        if i == 0:
                            self.WA = self.WA - dW[i]
                        else:
                            self.WB = self.WB - dW[i]

    def reduce(self, X):
        X = self._norm(np.asarray(X, dtype=float))
        with np.errstate(over="ignore", invalid="ignore"):
            return 1.0 / (1.0 + np.exp(-X @ self.WA[:, 1:].T - np.tile(self.WA[:, 0][None, :], (X.shape[0], 1))))

    def recover(self, H):
        H = np.asarray(H, dtype=float)
        with np.errstate(over="ignore", invalid="ignore"):
            X = 1.0 / (1.0 + np.exp(-H @ self.WB[:, 1:].T - np.tile(self.WB[:, 0][None, :], (H.shape[0], 1))))
            return X * (self.upper - self.lower)[None, :] + self.lower[None, :]


def model_training(Mask, Dec, REAL, rng):

    allZero = np.all(~Mask, axis=0)
    allOne = np.all(Mask, axis=0)
    other = ~allZero & ~allOne
    no = int(other.sum())
    K = int(np.sum(np.mean(np.abs(Mask[:, other] * Dec[:, other]) > 1e-6, axis=0) > rng.random(no)))
    K = min(max(K, 1), Mask.shape[0])

    rbm = RBM(no, K, 10, 1, 0, 0.5, 0.1, rng)
    rbm.train(Mask[:, other])
    if REAL:
        dae = DAE(Dec.shape[1], K, 10, Dec.shape[0], 0.5, 0.5, 0.1, rng)
        dae.train(Dec)
    else:
        dae = None
    return rbm, dae, allZero, allOne


def _binary_crossover(P1, P2, rng):
    k = rng.random(P1.shape) < 0.5
    O1, O2 = P1.copy(), P2.copy()
    O1[k] = P2[k]
    O2[k] = P1[k]
    return np.vstack([O1, O2])


def _binary_mutation(Off, rng):
    Site = rng.random(Off.shape) < 1 / Off.shape[1]
    Off = Off.copy()
    Off[Site] = ~Off[Site]
    return Off


def _real_crossover(P1, P2, rng):
    disC = 20
    N, D = P1.shape
    beta = np.zeros((N, D))
    mu = rng.random((N, D))
    lo = mu <= 0.5
    beta[lo] = (2 * mu[lo]) ** (1 / (disC + 1))
    beta[~lo] = (2 - 2 * mu[~lo]) ** (-1 / (disC + 1))
    beta = beta * (-1.0) ** rng.integers(0, 2, size=(N, D))
    return np.vstack([(P1 + P2) / 2 + beta * (P1 - P2) / 2,
                      (P1 + P2) / 2 - beta * (P1 - P2) / 2])


def _real_mutation(Off, Lower, Upper, rng):
    disM = 20
    N, D = Off.shape
    Lower = np.tile(Lower, (N, 1))
    Upper = np.tile(Upper, (N, 1))
    Site = rng.random((N, D)) < 1 / D
    mu = rng.random((N, D))
    Off = np.fmin(np.fmax(Off, Lower), Upper)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = Site & (mu <= 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * ((2. * m + (1 - 2. * m) * (1 - (o - L) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)) - 1)
        t = Site & (mu > 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * (1 - (2. * (1 - m) + 2. * (m - 0.5) * (1 - (U - o) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)))
    return np.fmin(np.fmax(Off, Lower), Upper)


def operator(task, ParentDec, ParentMask, rbm, dae, Site, allZero, allOne):
    rng = task.rng
    h = ParentMask.shape[0] // 2
    P1Mask, P2Mask = ParentMask[:h], ParentMask[h:]
    P1Dec, P2Dec = ParentDec[:h], ParentDec[h:]
    D = ParentMask.shape[1]

    if Site.any():
        other = ~allZero & ~allOne
        OffTemp = _binary_crossover(rbm.reduce(P1Mask[np.ix_(Site, other)]),
                                    rbm.reduce(P2Mask[np.ix_(Site, other)]), rng)
        OffTemp = rbm.recover(OffTemp)
        OffMask = np.zeros((OffTemp.shape[0], D), dtype=bool)
        OffMask[:, other] = OffTemp
        OffMask[:, allOne] = True
    else:
        OffMask = np.zeros((0, D), dtype=bool)
    OffMask = np.vstack([OffMask, _binary_crossover(P1Mask[~Site], P2Mask[~Site], rng)])
    OffMask = _binary_mutation(OffMask, rng)

    if np.any(task.encoding != 4):
        if Site.any():
            OffDec = _real_crossover(dae.reduce(P1Dec[Site]), dae.reduce(P2Dec[Site]), rng)
            OffDec = dae.recover(OffDec)
        else:
            OffDec = np.zeros((0, D))
        OffDec = np.vstack([OffDec, _real_crossover(P1Dec[~Site], P2Dec[~Site], rng)])
        OffDec = _real_mutation(OffDec, task.lower, task.upper, rng)
        OffDec[:, task.encoding == 4] = 1
    else:
        OffDec = np.ones(OffMask.shape)
    return OffDec, OffMask


def environmental_selection(pop: Pop, Dec, Mask, N: int, len_: int, num: int):

    success = np.zeros(len(pop), dtype=bool)
    _, uni, _ = unique_rows(pop.objs)
    if len(uni) == 1:
        _, uni, _ = unique_rows(pop.decs)
    pop, Dec, Mask = pop[uni], Dec[uni], Mask[uni]
    N = min(N, len(pop))

    FrontNo, MaxFNo = NDSort(pop.objs, pop.cons, N)
    Next = FrontNo < MaxFNo

    CrowdDis = CrowdingDistance(pop.objs, FrontNo)

    Last = np.flatnonzero(FrontNo == MaxFNo)
    _, Rank = msort(CrowdDis[Last], True)
    Next[Last[Rank[:N - int(Next.sum())]]] = True

    success[uni[Next]] = True
    s1 = int(success[len_:len_ + num].sum())
    s2 = int(success[len_ + num:].sum())
    sRatio = (s1 + 1e-6) / (s1 + s2 + 1e-6)
    sRatio = min(max(sRatio, 0.1), 0.9)
    return pop[Next], Dec[Next], Mask[Next], FrontNo[Next], CrowdDis[Next], sRatio


def run(task, **params):
    rng = task.rng
    N, D = task.N, task.D

    P, _ = UniformPoint(N, D, "Latin", rng=rng)
    Dec = P * np.tile(task.upper - task.lower, (N, 1)) + np.tile(task.lower, (N, 1))
    Dec[:, task.encoding == 4] = 1
    Mask = UniformPoint(N, D, "Latin", rng=rng)[0] > 0.5
    Mask = task.insert_greedy(Mask)
    pop = task.evaluate(Dec * Mask)
    pop, Dec, Mask, FrontNo, CrowdDis, _ = environmental_selection(pop, Dec, Mask, N, 0, 0)

    rho = 0.5
    nh = math.ceil(N / 2)
    REAL = bool(np.any(task.encoding != 4))
    while task.not_terminated(pop):
        Site = rho > rng.random(nh)
        if Site.any():
            rbm, dae, allZero, allOne = model_training(Mask, Dec, REAL, rng)
        else:
            rbm = dae = allZero = allOne = None
        MatingPool = TournamentSelection(2, nh * 2, FrontNo, -CrowdDis, rng=rng)
        OffDec, OffMask = operator(task, Dec[MatingPool], Mask[MatingPool], rbm, dae, Site, allZero, allOne)
        off = task.evaluate(OffDec * OffMask)
        pop, Dec, Mask, FrontNo, CrowdDis, sRatio = environmental_selection(
            Pop.cat(pop, off), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), N, len(pop),
            2 * int(Site.sum()))
        rho = (rho + sRatio) / 2
    return task.result()
