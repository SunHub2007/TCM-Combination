"""NSGA-III (Deb and Jain, 2014) for binary encoding."""
from __future__ import annotations

import warnings

import numpy as np
import scipy.linalg as sla

from tcmsel.core import Pop
from tcmsel.operators import NDSort, OperatorGA, TournamentSelection, UniformPoint, libm_pow

NAME = "NSGA-III"
YEAR = 2014
REFERENCE = ("K. Deb and H. Jain. An evolutionary many-objective optimization algorithm using reference-point "
             "based non-dominated sorting approach, part I: Solving problems with box constraints. IEEE "
             "Transactions on Evolutionary Computation, 2014, 18(4): 577-601.")
CODING = "real/integer/label/binary/permutation"
DEFAULTS: dict = {}


def _seqsum_rows(A):
    S = np.zeros(A.shape[0])
    for m in range(A.shape[1]):
        S = S + A[:, m]
    return S


def _rsqrt(x):
    x = np.asarray(x, dtype=float)
    out = np.full(x.shape, np.inf)
    pos = x > 0
    out[pos] = libm_pow(x[pos], -0.5)
    out[np.isnan(x)] = np.nan
    return out


def pdist2_cosine(X, Y):
    with np.errstate(divide="ignore", invalid="ignore"):
        sx = _rsqrt(_seqsum_rows(X ** 2))
        sy = _rsqrt(_seqsum_rows(Y ** 2))
        XY = np.zeros((X.shape[0], Y.shape[0]))
        for m in range(X.shape[1]):
            XY = XY + X[:, None, m] * Y[None, :, m]
        return 1 - XY * sx[:, None] * sy[None, :]


def _solve_square(A, b):
    A = np.asarray(A, dtype=float)
    b = np.asarray(b, dtype=float)
    with warnings.catch_warnings(), np.errstate(all="ignore"):
        warnings.simplefilter("ignore")
        upper = not np.any(np.tril(A, -1))
        lower = not np.any(np.triu(A, 1))
        if upper or lower:
            if np.all(np.diag(A) != 0):
                return sla.solve_triangular(A, b, lower=lower and not upper, check_finite=False)
            return _substitute(A, b, lower=lower and not upper)
        if np.array_equal(A, A.T) and np.all(np.diag(A) > 0):
            try:
                c = sla.cho_factor(A, lower=False, check_finite=False)
                return sla.cho_solve(c, b, check_finite=False)
            except np.linalg.LinAlgError:
                pass
        lu, piv = sla.lu_factor(A, check_finite=False)
        return sla.lu_solve((lu, piv), b, check_finite=False)


def _substitute(A, b, lower):
    n = len(b)
    x = b.astype(float).copy()
    order = range(n) if lower else range(n - 1, -1, -1)
    for j in order:
        x[j] = x[j] / A[j, j]
        rest = range(j + 1, n) if lower else range(j - 1, -1, -1)
        for i in rest:
            x[i] = x[i] - x[j] * A[i, j]
    return x


def _nanmin_idx(A, axis):
    B = np.where(np.isnan(A), np.inf, A)
    idx = np.argmin(B, axis=axis)
    d = np.take_along_axis(A, np.expand_dims(idx, axis), axis=axis).squeeze(axis)
    return d, idx


def last_selection(PopObj1, PopObj2, K, Z, Zmin, rng):
    PopObj = np.vstack([PopObj1, PopObj2]) - Zmin[None, :]
    N, M = PopObj.shape
    N1 = PopObj1.shape[0]
    N2 = PopObj2.shape[0]
    NZ = Z.shape[0]


    Extreme = np.zeros(M, dtype=int)
    w = np.zeros((M, M)) + 1e-6 + np.eye(M)
    with np.errstate(divide="ignore", invalid="ignore"):
        for i in range(M):
            _, Extreme[i] = _nanmin_idx(np.fmax.reduce(PopObj / w[i][None, :], axis=1), 0)

    Hyperplane = _solve_square(PopObj[Extreme], np.ones(M))
    with np.errstate(divide="ignore", invalid="ignore"):
        a = 1.0 / Hyperplane
    if np.any(np.isnan(a)):
        a = np.fmax.reduce(PopObj, axis=0)
    with np.errstate(divide="ignore", invalid="ignore"):
        PopObj = PopObj / a[None, :]


    Cosine = 1 - pdist2_cosine(PopObj, Z)
    with np.errstate(invalid="ignore"):
        Distance = np.sqrt(_seqsum_rows(PopObj ** 2))[:, None] * np.sqrt(np.abs(1 - Cosine ** 2))
    d, pi = _nanmin_idx(Distance, 1)


    rho = np.bincount(pi[:N1], minlength=NZ).astype(float)


    Choose = np.zeros(N2, dtype=bool)
    Zchoose = np.ones(NZ, dtype=bool)
    piL = pi[N1:]
    while Choose.sum() < K:

        Temp = np.flatnonzero(Zchoose)
        Jmin = np.flatnonzero(rho[Temp] == rho[Temp].min())
        j = Temp[Jmin[rng.integers(0, len(Jmin))]]
        I = np.flatnonzero(~Choose & (piL == j))

        if len(I) > 0:
            if rho[j] == 0:
                _, s = _nanmin_idx(d[N1 + I], 0)
            else:
                s = rng.integers(0, len(I))
            Choose[I[s]] = True
            rho[j] = rho[j] + 1
        else:
            Zchoose[j] = False
    return Choose


def environmental_selection(pop: Pop, N: int, Z, Zmin, rng):
    if Zmin is None:
        Zmin = np.ones(Z.shape[1])

    FrontNo, MaxFNo = NDSort(pop.objs, pop.cons, N)
    Next = FrontNo < MaxFNo

    Last = np.flatnonzero(FrontNo == MaxFNo)
    Choose = last_selection(pop.objs[Next], pop.objs[Last], N - int(Next.sum()), Z, Zmin, rng)
    Next[Last[Choose]] = True
    return pop[Next]


def _feasible_min(P: Pop, Zmin):
    F = P.objs[np.all(P.cons <= 0, axis=1)]
    if Zmin is not None:
        F = np.vstack([Zmin[None, :], F])
    if F.shape[0] == 0:
        return None
    return np.fmin.reduce(F, axis=0)


def run(task, **params):

    Z, task.N = UniformPoint(task.N, task.M)
    pop = task.initialization()
    Zmin = _feasible_min(pop, None)

    while task.not_terminated(pop):
        MatingPool = TournamentSelection(2, task.N, pop.cv, rng=task.rng)
        off = OperatorGA(task, pop[MatingPool])
        Zmin = _feasible_min(off, Zmin)
        pop = environmental_selection(Pop.cat(pop, off), task.N, Z, Zmin, task.rng)
    return task.result()
