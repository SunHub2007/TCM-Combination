"""Random search: random subsets of 1 to K compounds, archive kept by NSGA-II selection."""
from __future__ import annotations

import numpy as np

from tcmsel.core import Pop
from tcmsel.algorithms.nsga2 import environmental_selection

NAME = "Random search"
YEAR = 0
REFERENCE = "Uniform random sampling of feasible subset sizes under the same evaluation budget."
CODING = "binary"
DEFAULTS: dict = {}


def _sample(task, n):
    from tcmsel.problem import K_MAX
    dec = np.zeros((n, task.D))
    for r in range(n):
        k = task.rng.integers(1, min(K_MAX, task.D) + 1)
        dec[r, task.rng.choice(task.D, size=k, replace=False)] = 1
    return dec


def run(task, **params):
    pop = task.evaluate(_sample(task, task.N))
    pop, _, _ = environmental_selection(pop, task.N)
    while task.not_terminated(pop):
        off = task.evaluate(_sample(task, task.N))
        pop, _, _ = environmental_selection(Pop.cat(pop, off), task.N)
    return task.result()
