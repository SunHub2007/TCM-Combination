"""SparseEA (Tian et al., 2020) for large-scale sparse problems, binary encoding."""
from __future__ import annotations

import math

import numpy as np

from tcmsel.core import Pop
from tcmsel.operators import (CrowdingDistance, NDSort, OperatorGAhalf, TournamentSelection, msort,
                                  unifrnd, unique_rows)

NAME = "SparseEA"
YEAR = 2020
REFERENCE = ("Y. Tian, X. Zhang, C. Wang, and Y. Jin. An evolutionary algorithm for large-scale sparse "
             "multi-objective optimization problems. IEEE Transactions on Evolutionary Computation, 2020, "
             "24(2): 380-393.")
CODING = "binary"
DEFAULTS: dict = {}


def environmental_selection(pop: Pop, Dec, Mask, N: int):

    _, uni, _ = unique_rows(pop.objs)
    pop, Dec, Mask = pop[uni], Dec[uni], Mask[uni]
    N = min(N, len(pop))

    FrontNo, MaxFNo = NDSort(pop.objs, pop.cons, N)
    Next = FrontNo < MaxFNo

    CrowdDis = CrowdingDistance(pop.objs, FrontNo)

    Last = np.flatnonzero(FrontNo == MaxFNo)
    _, Rank = msort(CrowdDis[Last], True)
    Next[Last[Rank[:N - int(Next.sum())]]] = True
    return pop[Next], Dec[Next], Mask[Next], FrontNo[Next], CrowdDis[Next]


def ts(fit, rng):
    if len(fit) == 0:
        return np.zeros(0, dtype=int)
    return TournamentSelection(2, 1, fit, rng=rng)


def variable_scores(task):
    D = task.D
    TDec, TMask, TempPop = [], [], []
    Fitness = np.zeros(D)
    for _ in range(1 + 4 * int(np.any(task.encoding != 4))):
        Dec = unifrnd(np.tile(task.lower, (D, 1)), np.tile(task.upper, (D, 1)), rng=task.rng)
        Dec[:, task.encoding == 4] = 1
        Mask = np.eye(D, dtype=bool)
        pop = task.evaluate(Dec * Mask)
        TDec.append(Dec)
        TMask.append(Mask)
        TempPop.append(pop)
        Fitness = Fitness + NDSort(np.hstack([pop.objs, pop.cons]), np.inf)[0]
    return np.vstack(TDec), np.vstack(TMask), Pop.cat(*TempPop), Fitness


def initial_population(task, Fitness):
    N, D = task.N, task.D
    Dec = unifrnd(np.tile(task.lower, (N, 1)), np.tile(task.upper, (N, 1)), rng=task.rng)
    Dec[:, task.encoding == 4] = 1
    Mask = np.zeros((N, D), dtype=bool)
    for i in range(N):
        k = math.ceil(task.rng.random() * D)
        Mask[i, TournamentSelection(2, k, Fitness, rng=task.rng)] = True
    return Dec, Mask


def operator(task, ParentDec, ParentMask, Fitness):
    rng = task.rng
    N, D = ParentDec.shape
    h = N // 2
    Parent1Mask = ParentMask[:h]
    Parent2Mask = ParentMask[h:]

    OffMask = Parent1Mask.copy()
    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(Parent1Mask[i] & ~Parent2Mask[i])
            index = index[ts(-Fitness[index], rng)]
            OffMask[i, index] = False
        else:
            index = np.flatnonzero(~Parent1Mask[i] & Parent2Mask[i])
            index = index[ts(Fitness[index], rng)]
            OffMask[i, index] = Parent2Mask[i, index]

    for i in range(h):
        if rng.random() < 0.5:
            index = np.flatnonzero(OffMask[i])
            index = index[ts(-Fitness[index], rng)]
            OffMask[i, index] = False
        else:
            index = np.flatnonzero(~OffMask[i])
            index = index[ts(Fitness[index], rng)]
            OffMask[i, index] = True

    if np.any(task.encoding != 4):
        OffDec = OperatorGAhalf(task, ParentDec, rng=rng)
        OffDec[:, task.encoding == 4] = 1
    else:
        OffDec = np.ones((h, D))
    return OffDec, OffMask


def run(task, **params):

    TDec, TMask, TempPop, Fitness = variable_scores(task)
    Dec, Mask = initial_population(task, Fitness)
    Mask = task.insert_greedy(Mask)
    pop = task.evaluate(Dec * Mask)
    pop, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
        Pop.cat(pop, TempPop), np.vstack([Dec, TDec]), np.vstack([Mask, TMask]), task.N)

    while task.not_terminated(pop):
        MatingPool = TournamentSelection(2, 2 * task.N, FrontNo, -CrowdDis, rng=task.rng)
        OffDec, OffMask = operator(task, Dec[MatingPool], Mask[MatingPool], Fitness)
        off = task.evaluate(OffDec * OffMask)
        pop, Dec, Mask, FrontNo, CrowdDis = environmental_selection(
            Pop.cat(pop, off), np.vstack([Dec, OffDec]), np.vstack([Mask, OffMask]), task.N)
    return task.result()
