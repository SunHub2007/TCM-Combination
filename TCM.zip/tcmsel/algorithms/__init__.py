"""Multi-objective evolutionary algorithms and random search."""

ALGORITHMS = {'SPEA2': 'spea2', 'NSGA-II': 'nsga2', 'NSGA-III': 'nsga3', 'SparseEA': 'sparseea',
              'MOEA/PSL': 'moeapsl', 'PM-MOEA': 'pmmoea', 'Random': 'random_search'}
