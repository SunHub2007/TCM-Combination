"""SPEA2 (Zitzler et al., 2001) for binary encoding.

Infeasible solutions are handled by constrained dominance in the fitness assignment: a solution with a
smaller overall constraint violation dominates one with a larger violation, and solutions with equal
violation are compared by Pareto dominance."""
from __future__ import annotations

import math

import numpy as np

from tcmsel.core import Pop
from tcmsel.operators import OperatorGA, TournamentSelection, msort

NAME = "SPEA2"
YEAR = 2001
REFERENCE = ("E. Zitzler, M. Laumanns, and L. Thiele. SPEA2: Improving the strength Pareto evolutionary "
             "algorithm. Proceedings of the Conference on Evolutionary Methods for Design, Optimization "
             "and Control with Applications to Industrial Problems, 2001, 95-100.")
CODING = "real/integer/label/binary/permutation"
DEFAULTS: dict = {}


def pdist2_euclid(A, B):
    A = np.asarray(A, dtype=float)
    B = np.asarray(B, dtype=float)
    S = np.zeros((A.shape[0], B.shape[0]))
    for m in range(A.shape[1]):
        S = S + (A[:, None, m] - B[None, :, m]) ** 2
    return np.sqrt(S)


def cal_fitness(PopObj, PopCon=None):
    PopObj = np.asarray(PopObj, dtype=float)
    N = PopObj.shape[0]
    CV = np.zeros(N) if PopCon is None else np.sum(np.maximum(0.0, np.asarray(PopCon, dtype=float).reshape(N, -1)), axis=1)

    lt = np.any(PopObj[:, None, :] < PopObj[None, :, :], axis=2)
    gt = np.any(PopObj[:, None, :] > PopObj[None, :, :], axis=2)
    Dominate = (CV[:, None] < CV[None, :]) | ((CV[:, None] == CV[None, :]) & lt & ~gt)
    np.fill_diagonal(Dominate, False)

    S = Dominate.sum(axis=1).astype(float)

    R = Dominate.T.astype(float) @ S

    Distance = pdist2_euclid(PopObj, PopObj)
    np.fill_diagonal(Distance, np.inf)
    Distance = np.sort(Distance, axis=1)
    D = 1.0 / (Distance[:, math.floor(math.sqrt(N)) - 1] + 2)
    return R + D


def truncation(PopObj, K):
    Distance = pdist2_euclid(PopObj, PopObj)
    np.fill_diagonal(Distance, np.inf)
    n = PopObj.shape[0]
    Del = np.zeros(n, dtype=bool)
    while Del.sum() < K:
        Remain = np.flatnonzero(~Del)
        Temp = np.sort(Distance[np.ix_(Remain, Remain)], axis=1)
        Del[Remain[_lexmin_row(Temp)]] = True
    return Del


def _lexmin_row(T):
    cand = np.arange(T.shape[0])
    for c in range(T.shape[1]):
        if len(cand) == 1:
            break
        col = T[cand, c]
        cand = cand[col == col.min()]
    return int(cand[0])


def environmental_selection(pop: Pop, N: int):
    Fitness = cal_fitness(pop.objs, pop.cons)
    Next = Fitness < 1
    if Next.sum() < N:
        _, Rank = msort(Fitness)
        Next[Rank[:N]] = True
    elif Next.sum() > N:
        Del = truncation(pop.objs[Next], int(Next.sum()) - N)
        Temp = np.flatnonzero(Next)
        Next[Temp[Del]] = False
    return pop[Next], Fitness[Next]


def run(task, **params):

    pop = task.initialization()
    Fitness = cal_fitness(pop.objs, pop.cons)

    while task.not_terminated(pop):
        MatingPool = TournamentSelection(2, task.N, Fitness, rng=task.rng)
        off = OperatorGA(task, pop[MatingPool])
        pop, Fitness = environmental_selection(Pop.cat(pop, off), task.N)
    return task.result()
