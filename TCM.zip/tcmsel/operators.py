"""Non-dominated sorting, crowding distance, selection, and variation operators."""
from __future__ import annotations

import math
from itertools import combinations

import numpy as np

from tcmsel.core import Pop


def rowsum(A) -> np.ndarray:
    A = np.asarray(A, dtype=float)
    if A.ndim == 1:
        A = A[None, :]
    if A.shape[1] == 0:
        return np.zeros(A.shape[0])
    return np.cumsum(A, axis=1)[:, -1]


def seqsum(x) -> float:
    x = np.asarray(x, dtype=float).ravel()
    return float(np.cumsum(x)[-1]) if x.size else 0.0


def rowprod(A) -> np.ndarray:
    A = np.asarray(A, dtype=float)
    if A.shape[1] == 0:
        return np.ones(A.shape[0])
    return np.cumprod(A, axis=1)[:, -1]


_libm_pow = np.frompyfunc(math.pow, 2, 1)


def libm_pow(a, b) -> np.ndarray:
    return np.asarray(_libm_pow(np.asarray(a, dtype=float), np.asarray(b, dtype=float)), dtype=float)


def msort(x, descend: bool = False):
    x = np.asarray(x, dtype=float).ravel()
    if not descend:
        idx = np.argsort(x, kind="stable")
    else:
        nan = np.isnan(x)
        nn = np.flatnonzero(~nan)
        idx = np.concatenate([np.flatnonzero(nan), nn[np.argsort(-x[nn], kind="stable")]])
    return x[idx], idx


def sortrows(A, cols=None):
    A = np.asarray(A, dtype=float)
    if A.ndim == 1:
        A = A[:, None]
    if cols is None:
        cols = list(range(1, A.shape[1] + 1))
    idx = np.arange(A.shape[0])
    for c in reversed(list(cols)):
        _, o = msort(A[idx, abs(c) - 1], descend=c < 0)
        idx = idx[o]
    return A[idx], idx


def unique_rows(A):
    A = np.asarray(A, dtype=float)
    if A.ndim == 1:
        A = A[:, None]
    n = A.shape[0]
    if n == 0:
        return A.copy(), np.zeros(0, int), np.zeros(0, int)
    _, order = sortrows(A)
    S = A[order]
    new = np.ones(n, bool)
    new[1:] = np.any(S[1:] != S[:-1], axis=1)
    grp = np.cumsum(new) - 1
    ic = np.empty(n, int)
    ic[order] = grp
    ia = order[new]
    return S[new], ia, ic


def mmod(x, y):
    x = np.asarray(x, dtype=float)
    y = np.asarray(y, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        q = x / y
        r = np.where(np.round(q) == q, 0.0, x - y * np.floor(q))
        r = np.where((r != 0) & ((r < 0) != (y < 0)), r + y, r)
        r = np.where(y == 0, x, r)
    return r


def pdist2(A, B, metric: str = "euclidean"):
    from scipy.spatial.distance import cdist
    A = np.atleast_2d(np.asarray(A, dtype=float))
    B = np.atleast_2d(np.asarray(B, dtype=float))
    m = metric.lower()
    if m == "euclidean":
        return cdist(A, B, "euclidean")
    if m == "squaredeuclidean":
        return cdist(A, B, "sqeuclidean")
    if m == "cosine":
        with np.errstate(divide="ignore", invalid="ignore"):
            na = np.sqrt(np.sum(A ** 2, axis=1))[:, None]
            nb = np.sqrt(np.sum(B ** 2, axis=1))[None, :]
            return 1.0 - (A @ B.T) / (na * nb)
    if m == "cityblock":
        return cdist(A, B, "cityblock")
    if m in ("chebychev", "chebyshev"):
        return cdist(A, B, "chebyshev")
    if m == "minkowski":
        return cdist(A, B, "minkowski", p=2)
    raise ValueError(metric)


def unifrnd(lower, upper, size=None, rng=None):
    lower = np.asarray(lower, dtype=float)
    upper = np.asarray(upper, dtype=float)
    shape = np.broadcast(lower, upper).shape if size is None else size
    return lower + (upper - lower) * rng.random(shape)


def randperm(n: int, k: int | None = None, rng=None) -> np.ndarray:
    p = rng.permutation(n)
    return p if k is None else p[:k]


def _rng_of(Problem, rng):
    if rng is not None:
        return rng
    r = getattr(Problem, "rng", None)
    if r is None:
        raise ValueError("pass rng= (Problem has no .rng)")
    return r


def _dominated_matrix(F):
    le = np.all(F[None, :, :] <= F[:, None, :], axis=2)
    lt = np.any(F[None, :, :] < F[:, None, :], axis=2)
    return le & lt


def NDSort(PopObj, *args):
    PopObj = np.array(PopObj, dtype=float, copy=True)
    if PopObj.ndim == 1:
        PopObj = PopObj[:, None]
    N, M = PopObj.shape
    if len(args) == 1:
        nSort = args[0]
    elif len(args) == 2:
        PopCon, nSort = args
        PopCon = np.asarray(PopCon, dtype=float).reshape(N, -1)
        Infeasible = np.any(PopCon > 0, axis=1)
        if Infeasible.any():
            mx = np.fmax.reduce(PopObj, axis=0)
            cv = rowsum(np.maximum(0.0, PopCon[Infeasible]))
            PopObj[Infeasible] = mx[None, :] + cv[:, None]
    else:
        raise TypeError("NDSort(PopObj, nSort) or NDSort(PopObj, PopCon, nSort)")
    FrontNo = np.full(N, np.inf)
    if N == 0:
        return FrontNo, 0
    target = min(float(nSort), N)
    MaxFNo = 0
    if N <= 4000:
        dom = _dominated_matrix(PopObj)
        cnt = dom.sum(axis=1)
        remaining = np.ones(N, bool)
        nsorted = 0
        while nsorted < target:
            MaxFNo += 1
            front = remaining & (cnt == 0)
            FrontNo[front] = MaxFNo
            remaining &= ~front
            nsorted += int(front.sum())
            if remaining.any():
                cnt = cnt - dom[:, front].sum(axis=1)
    else:
        remaining = np.arange(N)
        nsorted = 0
        while nsorted < target:
            MaxFNo += 1
            R = PopObj[remaining]
            isdom = np.zeros(len(remaining), bool)
            for s in range(0, len(remaining), 512):
                isdom[s:s + 512] = _dominated_matrix_block(R[s:s + 512], R)
            front = remaining[~isdom]
            FrontNo[front] = MaxFNo
            remaining = remaining[isdom]
            nsorted += len(front)
    return FrontNo, MaxFNo


def _dominated_matrix_block(Fi, F):
    le = np.all(F[None, :, :] <= Fi[:, None, :], axis=2)
    lt = np.any(F[None, :, :] < Fi[:, None, :], axis=2)
    return np.any(le & lt, axis=1)


def CrowdingDistance(PopObj, FrontNo=None):
    PopObj = np.asarray(PopObj, dtype=float)
    N, M = PopObj.shape
    FrontNo = np.ones(N) if FrontNo is None else np.asarray(FrontNo, dtype=float).ravel()
    CrowdDis = np.zeros(N)
    fronts = np.unique(FrontNo)
    fronts = fronts[~np.isinf(fronts)]
    with np.errstate(divide="ignore", invalid="ignore"):
        for f in fronts:
            Front = np.flatnonzero(FrontNo == f)
            O = PopObj[Front]
            Fmax = np.fmax.reduce(O, axis=0)
            Fmin = np.fmin.reduce(O, axis=0)
            for i in range(M):
                _, Rank = msort(O[:, i])
                CrowdDis[Front[Rank[0]]] = np.inf
                CrowdDis[Front[Rank[-1]]] = np.inf
                if len(Front) > 2:
                    mid = Front[Rank[1:-1]]
                    CrowdDis[mid] = CrowdDis[mid] + (O[Rank[2:], i] - O[Rank[:-2], i]) / (Fmax[i] - Fmin[i])
    return CrowdDis


def FitnessSingle(Population):
    PopCon = rowsum(np.maximum(0.0, Population.cons))
    Feasible = PopCon <= 0
    obj = np.asarray(Population.objs, dtype=float)[:, 0]
    with np.errstate(invalid="ignore"):
        return Feasible * obj + (~Feasible) * (PopCon + 1e10)


def TournamentSelection(K, N, *fitness, rng=None):
    cols = [np.asarray(f, dtype=float).reshape(-1) for f in fitness]
    Fit = np.column_stack(cols)
    _, _, Loc = unique_rows(Fit)
    Parents = rng.integers(0, len(cols[0]), size=(int(K), int(N)))
    best = np.argmin(Loc[Parents], axis=0)
    return Parents[best, np.arange(int(N))]


def RouletteWheelSelection(N, Fitness, rng=None):
    Fitness = np.asarray(Fitness, dtype=float).ravel()
    Fitness = Fitness - min(np.min(Fitness), 0) + 1e-6
    Fitness = np.cumsum(1.0 / Fitness)
    Fitness = Fitness / np.max(Fitness)
    r = rng.random(int(N))
    return np.searchsorted(Fitness, r, side="left")


def UniformPoint(N, M, method: str = "NBI", rng=None):
    f = {"NBI": _nbi, "ILD": _ild, "MUD": _mud, "grid": _grid, "Latin": _latin}[method]
    if method == "Latin":
        return f(int(N), int(M), rng)
    if method == "MUD":
        return f(int(N), int(M))
    return f(N, int(M))


def _simplex_lattice(H, M):
    C = np.array(list(combinations(range(1, H + M), M - 1)), dtype=float).reshape(-1, M - 1)
    W = C - np.arange(M - 1)[None, :] - 1
    n = W.shape[0]
    return (np.hstack([W, np.full((n, 1), float(H))]) - np.hstack([np.zeros((n, 1)), W])) / H


def _nbi(N, M):
    H1 = 1
    while math.comb(H1 + M, M - 1) <= N:
        H1 += 1
    W = _simplex_lattice(H1, M)
    if H1 < M:
        H2 = 0
        while math.comb(H1 + M - 1, M - 1) + math.comb(H2 + M, M - 1) <= N:
            H2 += 1
        if H2 > 0:
            W2 = _simplex_lattice(H2, M)
            W = np.vstack([W, W2 / 2 + 1 / (2 * M)])
    W = np.fmax(W, 1e-6)
    return W, W.shape[0]


def _ild(N, M):
    I = M * np.eye(M)
    W = np.zeros((1, M))
    edgeW = W
    while W.shape[0] < N and M < N:
        edgeW = np.tile(edgeW, (M, 1)) + np.repeat(I, edgeW.shape[0], axis=0)
        edgeW, _, _ = unique_rows(edgeW)
        edgeW = edgeW[np.min(edgeW, axis=1) == 0]
        W = np.vstack([W + 1, edgeW])
    with np.errstate(invalid="ignore"):
        W = W / rowsum(W)[:, None]
    W = np.fmax(W, 1e-6)
    return W, W.shape[0]


def _mud(N, M):
    X = libm_pow(_good_lattice_point(N, M - 1), 1.0 / np.tile(np.arange(M - 1, 0, -1, dtype=float), (N, 1)))
    X = np.fmax(X, 1e-6)
    W = np.zeros((N, M))
    W[:, :-1] = (1 - X) * np.cumprod(X, axis=1) / X
    W[:, -1] = rowprod(X)
    return W, N


def _good_lattice_point(N, M):
    hm = np.array([i for i in range(1, N + 1) if math.gcd(i, N) == 1], dtype=float)
    udt = mmod(np.arange(1, N + 1, dtype=float)[:, None] * hm[None, :], N)
    udt[udt == 0] = N
    nComb = math.comb(len(hm), M)
    if nComb < 1e4:
        Comb = np.array(list(combinations(range(len(hm)), M)), dtype=int).reshape(-1, M)
        CD2 = np.array([_cal_cd2(udt[:, c]) for c in Comb])
        Data = udt[:, Comb[int(np.argmin(CD2))]]
    else:
        CD2 = np.zeros(N)
        for i in range(1, N + 1):
            UT = mmod(np.arange(1, N + 1, dtype=float)[:, None] * (float(i) ** np.arange(M, dtype=float))[None, :], N)
            CD2[i - 1] = _cal_cd2(UT)
        minIndex = int(np.argmin(CD2)) + 1
        Data = mmod(np.arange(1, N + 1, dtype=float)[:, None] * (float(minIndex) ** np.arange(M, dtype=float))[None, :], N)
        Data[Data == 0] = N
    return (Data - 1) / (N - 1)


def _cal_cd2(UT):
    N, S = UT.shape
    X = (2 * UT - 1) / (2 * N)
    CS1 = seqsum(rowprod(2 + np.abs(X - 1 / 2) - (X - 1 / 2) ** 2))

    T = (1 + 1 / 2 * np.abs(X[:, None, :] - 1 / 2) + 1 / 2 * np.abs(X[None, :, :] - 1 / 2)
         - 1 / 2 * np.abs(X[:, None, :] - X[None, :, :]))
    P = np.cumprod(T, axis=2)[:, :, -1]
    CS2i = np.cumsum(P, axis=1)[:, -1]
    CS2 = seqsum(CS2i)
    return (13 / 12) ** S - 2 ** (1 - S) / N * CS1 + 1 / (N ** 2) * CS2


def arange_inclusive(base, inc, limit):
    base, inc, limit = float(base), float(inc), float(limit)
    if inc == 0 or (limit - base) / inc < 0:
        return np.zeros(0)
    q = (limit - base + inc) / inc
    n = math.floor(q)
    if q - n > 1 - 3 * np.finfo(float).eps * max(1.0, abs(q)):
        n += 1
    r = base + np.arange(n) * inc
    if n and ((inc > 0 and r[-1] > limit) or (inc < 0 and r[-1] < limit)):
        r[-1] = limit
    return r


def _linspace_sym(a, b, n):
    n = int(n)
    if n < 1:
        return np.zeros(0)
    if n == 1:
        return np.array([float(b)])
    r = np.zeros(n)
    r[0], r[-1] = a, b
    delta = (b - a) / (n - 1)
    n2 = n // 2
    for i in range(1, n2):
        r[i] = a + i * delta
        r[n - 1 - i] = b - i * delta
    if n % 2 == 1:
        r[n2] = 0.0 if a == -b else (a + b) / 2
    return r


def _grid(N, M):
    gap = _linspace_sym(0.0, 1.0, math.ceil(float(N) ** (1 / M)))
    c = np.meshgrid(*([gap] * M), indexing="ij")
    W = np.column_stack([ci.ravel(order="F") for ci in c])
    return W, W.shape[0]


def _latin(N, M, rng):
    W = np.argsort(rng.random((N, M)), axis=0, kind="stable") + 1
    W = (rng.random((N, M)) + W - 1) / N
    return W, N


def _type_index(Problem):
    enc = np.asarray(Problem.encoding, dtype=int).ravel()
    return [np.flatnonzero(enc == i) for i in range(1, 6)]


def _bounds(Problem, D):
    lo = np.asarray(Problem.lower, dtype=float) * np.ones(D)
    up = np.asarray(Problem.upper, dtype=float) * np.ones(D)
    return lo, up


def _poly_mutation(Off, Lower, Upper, proM_over_D, disM, rng):
    n, D = Off.shape
    Site = rng.random((n, D)) < proM_over_D
    mu = rng.random((n, D))
    Off = np.minimum(np.maximum(Off, Lower), Upper)
    with np.errstate(divide="ignore", invalid="ignore"):
        t = Site & (mu <= 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * ((2.0 * m + (1 - 2.0 * m) * (1 - (o - L) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)) - 1)
        t = Site & (mu > 0.5)
        L, U, m, o = Lower[t], Upper[t], mu[t], Off[t]
        Off[t] = o + (U - L) * (1 - (2.0 * (1 - m) + 2.0 * (m - 0.5) * (1 - (U - o) / (U - L)) ** (disM + 1)) ** (1 / (disM + 1)))
    return Off


def _sbx_beta(N, D, proC, disC, rng):
    beta = np.zeros((N, D))
    mu = rng.random((N, D))
    lo = mu <= 0.5
    beta[lo] = (2 * mu[lo]) ** (1 / (disC + 1))
    beta[~lo] = (2 - 2 * mu[~lo]) ** (-1 / (disC + 1))
    beta = beta * (-1.0) ** rng.integers(0, 2, size=(N, D))
    beta[rng.random((N, D)) < 0.5] = 1
    beta[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = 1
    return beta


def _ga_real(P1, P2, lower, upper, proC, disC, proM, disM, rng, half):
    N, D = P1.shape
    beta = _sbx_beta(N, D, proC, disC, rng)
    if half:
        Off = (P1 + P2) / 2 + beta * (P1 - P2) / 2
        n = N
    else:
        Off = np.vstack([(P1 + P2) / 2 + beta * (P1 - P2) / 2, (P1 + P2) / 2 - beta * (P1 - P2) / 2])
        n = 2 * N
    Lower = np.tile(lower, (n, 1))
    Upper = np.tile(upper, (n, 1))
    return _poly_mutation(Off, Lower, Upper, proM / D, disM, rng)


def _uniform_cross(P1, P2, proC, rng):
    N, D = P1.shape
    k = rng.random((N, D)) < 0.5
    k[np.repeat(rng.random((N, 1)) > proC, D, axis=1)] = False
    return k


def _ga_label(P1, P2, lower, upper, proC, proM, rng):
    N, D = P1.shape
    k = _uniform_cross(P1, P2, proC, rng)
    O1, O2 = P1.copy(), P2.copy()
    O1[k], O2[k] = P2[k], P1[k]
    Off = np.vstack([O1, O2])
    Site = rng.random((2 * N, D)) < proM / D
    Rand = np.round(unifrnd(np.tile(lower, (2 * N, 1)), np.tile(upper, (2 * N, 1)), rng=rng))
    Off[Site] = Rand[Site]
    return Off


def _ga_label_half(P1, P2, proC, proM, rng):
    N, D = P1.shape
    k = _uniform_cross(P1, P2, proC, rng)
    Off = P1.copy()
    Off[k] = P2[k]
    Site = rng.random((N, D)) < proM / D
    Rand = rng.integers(1, D + 1, size=(N, D)).astype(float)
    Off[Site] = Rand[Site]
    for i in range(N):
        Lab = np.zeros(D)
        while not np.all(Lab):
            x = np.flatnonzero(Lab == 0)[0]
            Lab[Off[i] == Off[i, x]] = Lab.max() + 1
        Off[i] = Lab
    return Off


def _ga_binary(P1, P2, proC, proM, rng, half):
    N, D = P1.shape
    k = _uniform_cross(P1, P2, proC, rng)
    if half:
        Off = P1.copy()
        Off[k] = P2[k]
    else:
        O1, O2 = P1.copy(), P2.copy()
        O1[k], O2[k] = P2[k], P1[k]
        Off = np.vstack([O1, O2])
    Site = rng.random(Off.shape) < proM / D
    Off[Site] = 1.0 - (Off[Site] != 0)
    return Off


def _setdiff_stable(a, b):
    bs = set(b.tolist())
    return np.array([v for v in a if v not in bs], dtype=float)


def _insert_move(row, s, k):
    D = len(row)
    if s < k:
        idx = list(range(1, s)) + [k] + list(range(s, k)) + list(range(k + 1, D + 1))
    elif s > k:
        idx = list(range(1, k)) + list(range(k + 1, s)) + [k] + list(range(s, D + 1))
    else:
        return row
    return row[np.asarray(idx) - 1]


def _ga_permutation(P1, P2, proC, rng, half):
    N, D = P1.shape
    if half:
        Off = P1.copy()
        k = rng.integers(1, D + 1, size=N)
        for i in range(N):
            if rng.random() < proC:
                Off[i, k[i]:] = _setdiff_stable(P2[i], P1[i, :k[i]])
        n = N
    else:
        Off = np.vstack([P1, P2]).copy()
        k = rng.integers(1, D + 1, size=2 * N)
        for i in range(N):
            if rng.random() < proC:
                Off[i, k[i]:] = _setdiff_stable(P2[i], P1[i, :k[i]])
                Off[i + N, k[i]:] = _setdiff_stable(P1[i], P2[i, :k[i]])
        n = 2 * N
    k = rng.integers(1, D + 1, size=n)
    s = rng.integers(1, D + 1, size=n)
    for i in range(n):
        Off[i] = _insert_move(Off[i], int(s[i]), int(k[i]))
    return Off


def _ga(Problem, Parent, Parameter, rng, half):
    proC, disC, proM, disM = (1, 20, 1, 20) if Parameter is None else tuple(Parameter)
    rng = _rng_of(Problem, rng)
    evaluated = isinstance(Parent, Pop)
    PD = Parent.decs if evaluated else np.asarray(Parent, dtype=float)
    h = PD.shape[0] // 2
    P1, P2 = PD[:h], PD[h:2 * h]
    D = P1.shape[1]
    Off = np.zeros((h if half else 2 * h, D))
    T = _type_index(Problem)
    lower, upper = _bounds(Problem, D)
    r = np.concatenate([T[0], T[1]])
    if r.size:
        pm = proM if half else proM * len(r) / D
        Off[:, r] = _ga_real(P1[:, r], P2[:, r], lower[r], upper[r], proC, disC, pm, disM, rng, half)
    if T[2].size:
        if half:
            Off[:, T[2]] = _ga_label_half(P1[:, T[2]], P2[:, T[2]], proC, proM, rng)
        else:
            Off[:, T[2]] = _ga_label(P1[:, T[2]], P2[:, T[2]], lower[T[2]], upper[T[2]], proC,
                                     proM * len(T[2]) / D, rng)
    if T[3].size:
        pm = proM if half else proM * len(T[3]) / D
        Off[:, T[3]] = _ga_binary(P1[:, T[3]], P2[:, T[3]], proC, pm, rng, half)
    if T[4].size:
        Off[:, T[4]] = _ga_permutation(P1[:, T[4]], P2[:, T[4]], proC, rng, half)
    return Problem.evaluate(Off) if evaluated else Off


def OperatorGA(Problem, Parent, Parameter=None, rng=None):
    return _ga(Problem, Parent, Parameter, rng, half=False)


def OperatorGAhalf(Problem, Parent, Parameter=None, rng=None):
    return _ga(Problem, Parent, Parameter, rng, half=True)


def OperatorDE(Problem, Parent1, Parent2, Parent3, Parameter=None, rng=None):
    CR, F, proM, disM = (1, 0.5, 1, 20) if Parameter is None else tuple(Parameter)
    rng = _rng_of(Problem, rng)
    evaluated = isinstance(Parent1, Pop)
    if evaluated:
        Parent1, Parent2, Parent3 = Parent1.decs, Parent2.decs, Parent3.decs
    Parent1 = np.asarray(Parent1, dtype=float)
    Parent2 = np.asarray(Parent2, dtype=float)
    Parent3 = np.asarray(Parent3, dtype=float)
    N, D = Parent1.shape
    Site = rng.random((N, D)) < CR
    Off = Parent1.copy()
    Off[Site] = Off[Site] + F * (Parent2[Site] - Parent3[Site])
    lower, upper = _bounds(Problem, D)
    Off = _poly_mutation(Off, np.tile(lower, (N, 1)), np.tile(upper, (N, 1)), proM / D, disM, rng)
    return Problem.evaluate(Off) if evaluated else Off


def OperatorPSO(Problem, Particle, Pbest, Gbest, W=0.4, rng=None):
    rng = _rng_of(Problem, rng)
    X, Pb, Gb = Particle.decs, Pbest.decs, Gbest.decs
    N, D = X.shape
    V = Particle.adds if Particle.adds is not None else np.zeros((N, D))
    r1 = rng.random((N, D))
    r2 = rng.random((N, D))
    OffVel = W * V + r1 * (Pb - X) + r2 * (Gb - X)
    return Problem.evaluate(X + OffVel, OffVel)


def OperatorFEP(Problem, Population, rng=None):
    rng = _rng_of(Problem, rng)
    X = Population.decs
    N, D = X.shape
    default = rng.random((N, D))
    Eta = Population.adds if Population.adds is not None else default
    tau = 1 / np.sqrt(2 * np.sqrt(D))
    tau1 = 1 / np.sqrt(2 * D)
    G = np.repeat(rng.standard_normal((N, 1)), D, axis=1)
    Gj = rng.standard_normal((N, D))
    Cj = rng.standard_cauchy((N, D))
    OffDec = X + Eta * Cj
    OffEta = Eta * np.exp(tau1 * G + tau * Gj)
    return Problem.evaluate(OffDec, OffEta)


__all__ = ["NDSort", "CrowdingDistance", "UniformPoint", "FitnessSingle", "TournamentSelection",
           "RouletteWheelSelection", "OperatorGA", "OperatorGAhalf", "OperatorDE", "OperatorPSO",
           "OperatorFEP", "msort", "sortrows", "unique_rows", "mmod", "pdist2", "unifrnd", "randperm",
           "rowsum", "rowprod", "seqsum", "libm_pow", "arange_inclusive"]
